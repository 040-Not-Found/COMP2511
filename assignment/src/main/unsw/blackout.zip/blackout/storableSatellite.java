package unsw.blackout;

import java.util.List;

public interface storableSatellite {

    public int getAvaliableStorage();

    public List<File> getStoredFiles();
}
