package unsw.blackout;

import java.util.List;

import unsw.utils.Angle;

public abstract class Device{
    private String devicedId;
    private Angle position;
    private String type;
    private List<File> files;
    public Device(String deviceId, String type, Angle position) {
        this.devicedId = deviceId;
        this.type = type;
        this.position = position;
    }
    public String getDevicedId() {
        return devicedId;
    }

    public Angle getPosition() {
        return position;
    }

    public final Double getHeight() {
        return 69911.0;
    }
    public String getType() {
        return type;
    }

    public abstract int getTransferRange();

    public void addFile(String filename, String content) {
        boolean fileExist = false;
        for (File file : files) {
            if (file.getFilename().equals(filename)){
                fileExist = true;
            }
        }
        if(!fileExist) {
            files.add(new File(filename, content));
        }
    }

    public List<File> getFiles() {
        return files;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Device other = (Device) obj;
        if (devicedId == null) {
            if (other.devicedId != null)
                return false;
        } else if (!devicedId.equals(other.devicedId))
            return false;
        if (position == null) {
            if (other.position != null)
                return false;
        } else if (!position.equals(other.position))
            return false;
        return true;
    }


}
