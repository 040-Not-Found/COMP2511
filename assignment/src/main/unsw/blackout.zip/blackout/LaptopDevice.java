package unsw.blackout;

import unsw.utils.Angle;

public class LaptopDevice extends Device{
    private final int transferRange;
    public LaptopDevice(String deviceId, String type, Angle position) {
        super(deviceId, type, position);
        this.transferRange = 100000;
    }
    public final int getTransferRange() {
        return transferRange;
    }
    
}
