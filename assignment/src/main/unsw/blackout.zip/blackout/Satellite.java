package unsw.blackout;

import java.util.ArrayList;
import java.util.List;

import unsw.utils.Angle;

public abstract class Satellite {
    private String satelliteId;
    public String type;
    private double height;
    private Angle position;
    private List<String> connectedId = new ArrayList<>();
    /**
     * @param satelliteId 
     * @param type
     * @param height (km)
     * @param position (degrees)
     */
    public Satellite(String satelliteId, String type, double height, Angle position) {
        this.satelliteId = satelliteId;
        this.type = type;
        this.height = height;
        this.position = position;
    }

    /**
     * @return satellite's id
     */
    public String getSatelliteId() {
        return satelliteId;
    }

    /**
     * @return satellite's height (km)
     */
    public double getHeight() {
        return height;
    }

    /**
     * @return satellite's type
     */
    public String getType() {
        return type;
    }

    /**
     * @return satellite's position (degrees)
     */
    public Angle getPosition() {
        return position;
    }
    
    /**
     * @param position (degrees)
     */
    public void setPosition(Angle position) {
        this.position = position;
    }

    public abstract int getLinearVelocity();

    public abstract int getTransferRange();

    /**
     * @return satellite's angular velocity (rad/min)
     */
    public double getAngularVelocity() {
        return this.getLinearVelocity()*100/this.getPosition().toRadians();
    }

    public void connectId(List<Device> devices, List<Satellite> satellites) {
        for (Device device : devices) {
            if (!(this instanceof StandardSatellite && (!(device instanceof HandheldDevice) || !(device instanceof HandheldDevice)))) {
                if (isVisible(device.getPosition(), device.getHeight()) && 
                    Distance(device.getHeight(), device.getPosition()) < MaxRange(device.getTransferRange())) {
                    this.connectedId.add(device.getDevicedId());
                }
            }
        }
        for (Satellite satellite : satellites) {                
            if (isVisible(satellite.getPosition(), satellite.getHeight()) && 
                Distance(satellite.getHeight(), satellite.getPosition()) < MaxRange(satellite.getTransferRange())) {
                this.connectedId.add(satellite.getSatelliteId());
            }
        }
    }

    public boolean isVisible(Angle Position, Double Height) {
        Angle maxAngle = Angle.fromRadians(Math.acos(Height/this.height));
        if (Math.abs(this.position.toDegrees()-Position.toDegrees()) <= maxAngle.toDegrees()) {
            return true;
        }
        return false;
    }

    public double Distance(Double height, Angle position) {
        return Math.sqrt(Math.pow(height, 2)+Math.pow(this.height, 2)-(2*Math.pow(height, 2)*Math.pow(this.height, 2)*Math.cos(position.toRadians())));
    }
    
    public int MaxRange(int transferRange) {
        return Math.min(this.getTransferRange(), transferRange);
    }

    public List<String> getConnectedId() {
        return this.connectedId;
    }

    /**
     * 
     * @param time
     * @return new satallite's position (degrees)
     */
    public Angle positionAfter(int time) {
        this.setPosition(Angle.fromRadians(Double.sum(this.getLinearVelocity()*time/this.getHeight(),this.position.toRadians())%(2*Math.PI)));
        return this.getPosition();
    }

}
