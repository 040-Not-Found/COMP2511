package unsw.blackout;

import java.util.List;
import java.util.ArrayList;

import unsw.utils.Angle;

public class ShrinkingSatellite extends Satellite implements storableSatellite {
    private final int linearVelocity;
    private final int transferRange;
    private final int sendingSpeed;
    private final int receivingSpeed;
    private int avaliableStorage;
    private List<File> storedFiles;
    public ShrinkingSatellite(String satelliteId, String type, double height, Angle position) {
        super(satelliteId, type, height, position);
        this.linearVelocity = 1000;
        this.transferRange = 200000;
        this.sendingSpeed = 1;
        this.receivingSpeed = 1;
        this.avaliableStorage = 80;
        this.storedFiles = new ArrayList<>();
    }

    /**
     * @return linear velocity (km/min)
     */
    public final int getLinearVelocity() {
        return this.linearVelocity;
    }

    public final int getTransferRange() {
        return transferRange;
    }
 
    public int getSendingSpeed() {
        return sendingSpeed;
    }

    public int getReceivingSpeed() {
        return receivingSpeed;
    }

    public int getAvaliableStorage() {
        return avaliableStorage;
    }

    public List<File> getStoredFiles() {
        return storedFiles;
    }
}
