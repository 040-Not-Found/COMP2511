package unsw.blackout;

import java.util.List;
import java.util.ArrayList;

import unsw.utils.Angle;

public class StandardSatellite extends Satellite {
    private final int linearVelocity;
    private final int transferRange;
    private final int sendingSpeed;
    private final int receivingSpeed;
    private int avaliableStorage;
    private List<File> storedFiles;

    public StandardSatellite(String satelliteId, String type, double height, Angle position) {
        super(satelliteId, type, height, position);
        this.linearVelocity = 2500;
        this.transferRange = 150000;
        this.sendingSpeed = 1;
        this.receivingSpeed = 1;
        this.avaliableStorage = 80;
        this.storedFiles = new ArrayList<>();
    }

    /**
     * @return linear velocity (km/min)
     */
    public final int getLinearVelocity() {
        return linearVelocity;
    }

    public final int getTransferRange() {
        return transferRange;
    }

    public int getSendingSpeed() {
        return sendingSpeed;
    }

    public int getReceivingSpeed() {
        return receivingSpeed;
    }

    public int getAvaliableStorage() {
        return avaliableStorage;
    }

    public List<File> getStoredFiles() {
        return storedFiles;
    }
    
}
