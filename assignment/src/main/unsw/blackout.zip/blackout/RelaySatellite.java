package unsw.blackout;

import unsw.utils.Angle;

public class RelaySatellite extends Satellite {

    private final int linearVelocity;
    private final int transferRange;
    public RelaySatellite(String satelliteId, String type, double height, Angle position) {
        super(satelliteId, type, height, position);
        this.linearVelocity = 1500;
        this.transferRange = 300000;
    }

    /**
     * @return linear velocity (km/min)
     */
    public final int getLinearVelocity() {
        return linearVelocity;
    }

    public final int getTransferRange() {
        return transferRange;
    }
}
