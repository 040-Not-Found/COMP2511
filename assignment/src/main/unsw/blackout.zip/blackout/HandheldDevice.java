package unsw.blackout;

import unsw.utils.Angle;

public class HandheldDevice extends Device{
    private final int transferRange;
    public HandheldDevice(String deviceId, String type, Angle position) {
        super(deviceId, type, position);
        this.transferRange = 50000;
    }
    public final int getTransferRange() {
        return this.transferRange;
    }
    
}
