package unsw.blackout;

import java.util.ArrayList;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

import unsw.response.models.EntityInfoResponse;
import unsw.response.models.FileInfoResponse;
import unsw.utils.Angle;

public class BlackoutController {
    private List<Device> devices = new ArrayList<Device>();
    private List<Satellite> satellites = new ArrayList<Satellite>();
    public void createDevice(String deviceId, String type, Angle position) {
        if (searchDevice(deviceId) == null && searchSatellite(deviceId) == null) {
            if (type.equals("HandheldDevice")) {
                devices.add(new HandheldDevice(deviceId, type, position));
            } else if (type.equals("LaptopDevice")) {
                devices.add(new LaptopDevice(deviceId, type, position));
            } else if (type.equals("DesktopDevice")) {
                devices.add(new DesktopDevice(deviceId, type, position));
            }
        }
    }

    public void removeDevice(String deviceId) {
        devices.remove(searchDevice(deviceId));
    }

    public void createSatellite(String satelliteId, String type, double height, Angle position) {
        if (searchSatellite(satelliteId) == null && searchDevice(satelliteId) == null) {
            if (type.equals("StandardSatellite")) {
                satellites.add(new StandardSatellite(satelliteId, type, height, position));                
            } else if (type.equals("ShrinkingSatellite")) {
                satellites.add(new ShrinkingSatellite(satelliteId, type, height, position));
            } else if (type.equals("RelaySatellite")) {
                satellites.add(new RelaySatellite(satelliteId, type, height, position));
            }
        }
    }

    public void removeSatellite(String satelliteId) {
        satellites.remove(searchSatellite(satelliteId));
    }

    public List<String> listDeviceIds() {
        List<String> deviceIdList = new ArrayList<>();
        for (Device device : devices) {
            deviceIdList.add(device.getDevicedId());
        }
        return deviceIdList;
    }

    public List<String> listSatelliteIds() {
        List<String> satelliteIdList = new ArrayList<>();
        for (Satellite satellite : satellites) {
            satelliteIdList.add(satellite.getSatelliteId());
        }
        return satelliteIdList;
    }

    public void addFileToDevice(String deviceId, String filename, String content) {
        for (Device device : devices) {
            if (device.getDevicedId().equals(deviceId)) {
                device.addFile(filename, content);
            }
        }
    }

    public EntityInfoResponse getInfo(String id) {
        Device device = searchDevice(id);
        if (device != null) {
            Map<String, FileInfoResponse> map = new HashMap<>();
            for (File file : device.getFiles()) {
                map.put("String", new FileInfoResponse(file.getFilename(),file.getContent(),file.getFileSize(),file.hasTransferCompleted()));
            }
            return new EntityInfoResponse(id, device.getPosition(), device.getHeight(), device.getType(), map);
        }
 
        Satellite satellite = searchSatellite(id);
        if (satellite != null) {
            return new EntityInfoResponse(id, satellite.getPosition(), satellite.getHeight(), satellite.getType());
        }
        return null;
    }

    public void simulate() {
    }


    /**
     * Simulate for the specified number of minutes.
     * You shouldn't need to modify this function.
     */
    public void simulate(int numberOfMinutes) {
        for (int i = 0; i < numberOfMinutes; i++) {
            simulate();
        }
    }

    public List<String> communicableEntitiesInRange(String id) {
        return new ArrayList<>();
    }

    public void sendFile(String fileName, String fromId, String toId) throws FileTransferException {
        if (searchSatellite(fromId) instanceof RelaySatellite) {
            // 直接传送
        }
    }

    public Device searchDevice(String id) {
        for (Device device : devices) {
            if (device.getDevicedId().equals(id)) {
                return device;
            }
        }
        return null;
    }

    public Satellite searchSatellite(String id) {
        for (Satellite satellite : satellites) {
            if (satellite.getSatelliteId().equals(id)) {
                return satellite;
            }
        }
        return null;
    }

    public static void main(String[] args) {

    }
}
