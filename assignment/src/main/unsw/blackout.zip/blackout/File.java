package unsw.blackout;

public class File{
    private String filename;
    private String content;
    private boolean hasTransferCompleted;
    public File(String filename, String content) {
        this.filename = filename;
        this.content = content;
    }
    public String getFilename() {
        return filename;
    }
    public String getContent() {
        return content;
    }
    public int getFileSize() {
        return this.getContent().length();
    }

    public void setHasTransferCompleted(boolean completed) {
        this.hasTransferCompleted = completed;
    }
    public boolean hasTransferCompleted() {
        return hasTransferCompleted;
    }
    
}
